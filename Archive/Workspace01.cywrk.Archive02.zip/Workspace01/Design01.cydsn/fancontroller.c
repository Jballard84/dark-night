/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
//#include <removeOffsetNoise.h>
//#include <measurement.h>
//#include <device.h>


#include <macros.h>

 void GetTemp(){
    /* Voltages across reference resistor and thermistor*/
	int32 iVref, iVtherm;
	/* Resistance of Thermistor*/
	uint32 iRes;
	/* Temperature value in 100ths of a degree C*/
	int32 iTemp;
    /*Decimal Temp*/
    int decTemp;
    /*Fractional Temp*/
    int32 fracTemp;

    	/* Measure Voltage Across Thermistor*/
    	iVtherm = MeasureResistorVoltage(AMUX_1_VT); 
		/* Measure Voltage Across Reference Resistor*/
    	iVref = MeasureResistorVoltage(AMUX_1_VREF);
	   	/*Calculate the resistance of the Thermistor*/
		iRes = (int32)(((float)iVtherm / iVref) * REFERENCE_RESISTOR);
        /* Use the thermistor component API function call to obtain 
        the temperature corresponding to the resistance measured*/	
    	iTemp = Thermistor_1_GetTemperature(iRes);
    	/*Determine decimal portion of temperature by dividing temperature by 100*/
        decTemp = iTemp/100;
        decTemp = decTemp*(9/5) + 32;//converts to Fahrenheit
         
        /*Determine fraction portion of temperature by subtracting decimal portion from result*/
        fracTemp = iTemp - (decTemp * 100);
        /*If fractional temperature is negative make it positive*/
        if(fracTemp < 0)
        {
            fracTemp *= -1;
        }
        
        CheckTemp(decTemp); // to see if you need to cycle glow plugs
       
}
  void  CheckTemp(int temp){
    extern volatile int Not_runing;
    if((temp<=COLD) || (temp<=WARMTemp)){  // temp is less than 35 degrees full cycle to glow plugs plus keep cycling after running  
       if(Not_runing!=0) {
        Glowglowplugs(fullplusafter);
    }
        return;// dont need fans yet so return
    }
    else if((temp>=WARMTemp) && (temp<HOT)) { // temp is in between 120 and 190 so only half cycle and no after cycling 
        Glowglowplugs(half);
        GetFanSpeed(temp);   
     } 
    else if(temp>HOT){
        GetFanSpeed(temp);
    }
    
}

   void GetFanSpeed(int temp){
    extern volatile int fanSPEED1;
    extern volatile int fanSPEED2;
    
    if((temp>=LOW1) && (temp<LOW2)){  // temp is between 150 and 160
        fanSPEED1=twentyfive;
        SetFanSpeed(fanSPEED1,0);
       return;
    }
    else if((temp>=LOW2) && (temp<HALF1)) { // temp is in between 160 and 170 
        fanSPEED1=fiffty;
        fanSPEED2=twentyfive;
        SetFanSpeed(fanSPEED1,fanSPEED2);
        
        return;
    }
    else if((temp>=HALF1) && (temp<THREEQUATER1HALF2)) { // temp is in between 170 and 180 
        fanSPEED1=seventyfive;
        fanSPEED2=fiffty;
        SetFanSpeed(fanSPEED1,fanSPEED2);
        
        return;
    }
    else if((temp>=THREEQUATER1HALF2) && (temp<FULL1THREEQUARTER2)) { // temp is in between 180 and 190 
        fanSPEED1=onehundred;
        fanSPEED2=fiffty;
        SetFanSpeed(fanSPEED1,fanSPEED2);
        return;
    }
    
   else if((temp>=FULL1THREEQUARTER2) && (temp<FULL2)) { // temp is in between 190 and 195 
        fanSPEED1=onehundred;
        fanSPEED2=seventyfive;
        SetFanSpeed(fanSPEED1,fanSPEED2);
        return;
    }
    else{                                                // temp is over 195
        fanSPEED1=onehundred;
        fanSPEED2=onehundred;
        SetFanSpeed(fanSPEED1,fanSPEED2);
    }   
    return;
}
void SetFanSpeed(int fanspeed1,int fanspeed2){
    extern volatile int fanSPEED1;
    extern volatile int fanSPEED2;
    PWM_1_FANCONTROLLER_Start();
    PWM_1_FANCONTROLLER_WriteCompare1(fanspeed1);
    PWM_1_FANCONTROLLER_WriteCompare2(fanspeed2);
    
}
/* [] END OF FILE */
