/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <measurement.h>
#include<Control_Reg_2.h>
#include <removeOffsetNoise.h>
#include <device.h>
#include <AMux_1.h>
#include <ADC_DelSig_1.h>
#include <fancontroller.h>
#include <stdio.h>
#include <glowplugcontroller.h>
#include <PWM_1.h>
#include <Pin_11.h>
#include<Timer_Sytem.h>
#include<Control_Reg_1.h>
#define CSV_entries (3749)
#define Timer_Sytem_period (16777216)
#define ALWAYS (1)
#define Clock_freq (24000000)
#define Not_running_Idle (200000)
#define Runing (0)
#define Not_Runing (1)
#define HOT (170)
#define LOWTemp (40)
#define WARMTemp (120)
#define COLD (35)
#define fullplusafter (1)
#define thirtysec (30)
#define half (2)
#define LOW1 (150)
#define LOW2 (160)
#define HALF1   (170)
#define THREEQUATER1HALF2   (180)
#define FULL1THREEQUARTER2  (190)
#define FULL2   (195)
#define twentyfive (63)
#define fiffty (127)
#define seventyfive (191)
#define onehundred (255)
#define high    (1)
#define low (0)
#define off (0)
 /* filter coefficent for rtd sensor */
    #define RTD_FILTER_COEFF_SHIFT  0
    #define MAX_FILTER_COEFF_SHIFT  8
    
    //number of sensors reading that require fltering
    #define NUM_SENSORS 2
    
    //number of each sensor
    #define REF_RES 1
    #define THERMISTOR      0
    
    //filter feedforward. it is set equal to 100 adc counts it has been scaled by 256 to account for maximum_filter_coeff 
    #define FILTER_FEEDFORWARD  50*256
    
    #define AMUX_1_VT 0
    #define AMUX_1_VREF 1
    #define AMUX_1_CDS 2
    #define REFERENCE_RESISTOR 10000
/* [] END OF FILE */
