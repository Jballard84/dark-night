/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#if !defined(glowplugcontroller_H)
    #define glowplugcontroller_H
    #include <device.h>
   
    void Glowglowplugs(int which_cycle);
    #endif
/* [] END OF FILE */
