/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <macros.h>
// need to check if it is running 
	void Glowglowplugs(int which_cycle){
        extern volatile int Not_runing;
        extern volatile int cycles;
    switch (which_cycle){
    case fullplusafter:
        if (Not_runing==1){
        Pin_11_Write(high);//writes pin high to energize the glow plug relay
        CyDelay(35000);     // waits 35 sec
        Pin_11_Write(low);  // turns of the relay
        }
        else{
            if(cycles==0){
               for (int i=0 ; i<=10;i++){
                   CyDelay(15000);     //waits 15 sec
                   Pin_11_Write(high);
                   CyDelay(15000);
                   Pin_11_Write(low);
                  }
            cycles=1;
            }
        Pin_11_Write(low);
        }
        break;
         
    case half:
        if(Not_runing==1){
        Pin_11_Write(high);
        CyDelay(20000);     // 20 secs for warm engine
        Pin_11_Write(low);
        }
        
        break;
     }
        
        
        
        
    }
/* [] END OF FILE */
