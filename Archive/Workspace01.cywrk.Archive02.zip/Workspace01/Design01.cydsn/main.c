/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <isr_CKP_counter.h>
#include <Clock_1.h>
#include <Timer_1.h>
#include <Timer_Sytem.c>
#include <isr_Not_Runing.h>
#include <ADC_DelSig_1.h>
#include <AMux_1.h>
#include <Opamp_1.h>
#include <VDAC8_1.h>
#include <removeOffsetNoise.h>
#include <measurement.h>
#include <device.h>
#include <fancontroller.h>
#include <stdio.h>  
#include<Clock_2.h>

volatile float freq;
volatile static int counter=0;
volatile int Not_runing=1;
volatile int cycles =0;
volatile int LowTemp;
volatile int fanSPEED1=off;
volatile int fanSPEED2=off;
int main(void)
{
     isr_CKP_counter_Start();
   
   isr_Not_Runing_Start();
   Timer_Sytem_Start();
   timer_clock_1_Start();
   Timer_1_Start();   
   //Timer_1_WritePeriod((uint32)(Not_running_Idle));
   WaveDAC8_1_Start();
   WaveDAC8_2_Start();
   ADC_DelSig_1_StartConvert();
   AMux_1_Start();
   Opamp_1_Start();
   VDAC8_1_Start();
   CyGlobalIntEnable; /* Enable global interrupts. */
   PWM_1_FANCONTROLLER_Enable();   
Pin_12_Write(high);
Clock_2_Start();
  // GetTemp();
   
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
//need to check temp if temp is low cycle glow plugs before starting 
    while(ALWAYS){
        switch (Not_runing){
        case Runing:
            
            //GetTemp();
        break;
         
        case Not_Runing:
            Timer_1_WritePeriod((uint32)Not_running_Idle);
        break;
     }
        
  
    
    }
    
        
   
    
}

/* [] END OF FILE */
	
        
        
